// Name: Jake Natalizia
// Date: January 29, 2020
// Description: Outputs 'Hello, World!'

#include <stdio.h>

int main()
{
	printf("Hello,\nWorld!\n");
	return 0;
}
