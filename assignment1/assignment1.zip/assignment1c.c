// Name: Jake Natalizia
// Date: January 30, 2020
// Description: Outputs a given code

#include <stdio.h>

int main() {
	printf("  *  \n");
	printf(" *** \n");
	printf("*****\n");
	return 0;
}

