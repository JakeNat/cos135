// Name: Jake Natalizia
// Date: February 5, 2020
// Description: Use a suitable format specifier to complete the following code

#include <stdio.h>

int main() {
	char chr = 67;
	printf("Character having ASCII value 67 is %d.\n", chr);
	return 0;
}
