// Name: Jake Natalizia
// Date: February 5, 2020
// Description: Prints a given table to console

#include <stdio.h>

int main() 
{
	printf("Name\tAge\tCountry\n");
	printf("------------------------\n");
	printf("Peter\t23\tUSA\n");
	printf("Manuel\t43\tGermany\n");
	printf("Ken\t35\tChina\n");
	printf("Moz\t44\tGhana\n");
	return 0;
}
